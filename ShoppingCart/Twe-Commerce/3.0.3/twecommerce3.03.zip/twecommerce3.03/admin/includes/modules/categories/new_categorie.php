<?php
/* --------------------------------------------------------------
   $Id: new_categorie.php,v 1.5 2004/03/16 15:01:16 oldpa   Exp $

   TWE-Commerce - community made shopping
   http://www.oldpa.com.tw
   Copyright (c) 2003 TWE-Commerce
   --------------------------------------------------------------
   based on:
   (c) 2000-2001 The Exchange Project  (earlier name of osCommerce)
   (c) 2002-2003 osCommerce(categories.php,v 1.140 2003/03/24); www.oscommerce.com
   (c) 2003  nextcommerce (categories.php,v 1.37 2003/08/18); www.nextcommerce.org
   (c) 2003	 xt-commerce  www.xt-commerce.com

   Released under the GNU General Public License
   --------------------------------------------------------------
   Third Party contribution:
   Enable_Disable_Categories 1.3               Autor: Mikel Williams | mikel@ladykatcostumes.com
   New Attribute Manager v4b                   Autor: Mike G | mp3man@internetwork.net | http://downloads.ephing.com
   Category Descriptions (Version: 1.5 MS2)    Original Author:   Brian Lowe <blowe@wpcusrgrp.org> | Editor: Lord Illicious <shaolin-venoms@illicious.net>
   Customers Status v3.x  (c) 2002-2003 Copyright Elari elari@free.fr | www.unlockgsm.com/dload-osc/ | CVS : http://cvs.sourceforge.net/cgi-bin/viewcvs.cgi/elari/?sortby=date#dirlist

   Released under the GNU General Public License
   --------------------------------------------------------------*/
    if ( ($_GET['cID']) && (!$_POST) ) {
      $category_query = "select c.categories_id,
                                      c.group_ids,
									  c.categories_status,
                                      cd.language_id,
                                      cd.categories_name,
                                      cd.categories_heading_title,
                                      cd.categories_description,
                                      cd.categories_meta_title,
                                      cd.categories_meta_description,
                                      cd.categories_meta_keywords,
                                      c.categories_template,
                                      c.listing_template,
                                      c.products_sorting,
                                      c.products_sorting2,
                                      c.categories_image,
                                      c.sort_order,
                                      c.date_added,
                                      c.last_modified from " . TABLE_CATEGORIES . " c, " . 
	  TABLE_CATEGORIES_DESCRIPTION . " cd 
	  where c.categories_id = cd.categories_id 
	  and c.categories_id = '" . $_GET['cID'] . "'";
      $category = $db->Execute($category_query);

      $cInfo = new objectInfo($category->fields);
    } elseif ($_POST) {
      $cInfo = new objectInfo($_POST);
      $categories_name = $_POST['categories_name'];
      $categories_heading_title = $_POST['categories_heading_title'];
      $categories_description = $_POST['categories_description'];
      $categories_meta_title = $_POST['categories_meta_title'];
      $categories_meta_description = $_POST['categories_meta_description'];
      $categories_meta_keywords = $_POST['categories_meta_keywords'];
      $categories_url = $_POST['categories_url'];
    } else {
      $cInfo = new objectInfo(array());
    }

    $languages = twe_get_languages();

    $text_new_or_edit = ($_GET['action']=='new_category_ACD') ? TEXT_INFO_HEADING_NEW_CATEGORY : TEXT_INFO_HEADING_EDIT_CATEGORY;
?>
      <tr>
        <td><table border="0" width="100%" cellspacing="0" cellpadding="0">
          <tr>
            <td class="pageHeading"><?php echo sprintf($text_new_or_edit, twe_output_generated_category_path($current_category_id)); ?></td>
            <td class="pageHeading" align="right">
             <table border="0">
              <tr>
                 <td class="smallText" align="right"><?php echo TEXT_INFO_HEADING_NEW_CATEGORY.HEADING_TITLE_GOTO ?></td><td><div id="category_tree"><?php echo twe_draw_pull_down_menu('cPath', twe_get_category_tree(), $current_category_id, 'linkData="action=takecPath" id="createC"')?></div></td>
                 <td class="smallText" width="150"><div id="createB"></div></td>
                 <td><a href="Javascript:void();" linkData="action=removeCategory&cPath=<?php echo $_GET['cPath']?>&cid=<?php echo $_GET['cID']?>" id="removeC"><?php echo twe_image_button('button_delete.gif', IMAGE_DELETE)?></a></td>
              </tr>
             </table>
             </td>
          </tr>
        </table></td>
      </tr>   
       <tr>
       <td>
        <table width="100%" border="0" cellspacing="0" cellpadding="2">
        <tr>
        <td colspan="4">
 			<table width="100%"  border="0" cellspacing="0" cellpadding="2">
			<tr>
			<td class="main" width="200"><div id="loadCform"><form id="upload_c_img" method="post" action="categories.php?rType=ajax" enctype="multipart/form-data" ><?php echo TEXT_EDIT_CATEGORIES_IMAGE?><br /><?php echo twe_draw_file_field('categories_image', 'id="categories_image"');?><br><?php echo twe_draw_hidden_field('categories_previous_image', $cInfo->categories_image).twe_draw_hidden_field('action', 'upload_Cimg').twe_draw_hidden_field('cid', $_GET['cID']);?></form></div>
        <td><div id="view_c_img">
		<?php if ($cInfo->categories_image) { ?>
            <img src="<?php echo DIR_WS_CATALOG.'images/categories/'.$cInfo->categories_image; ?>" ><a href="Javascript:void();" linkData="action=removeCimg&img=<?php echo $cInfo->categories_image?>&cid=<?php echo $_GET['cID']?>" id="removeCImg"><img border="0" src="./images/icons/cross.gif"><span class="main"><?php echo TEXT_DELETE; ?></span></a><?php echo '&nbsp;' .$cInfo->categories_image; ?>
		<?php } ?></div>
        </td>            
          </tr>
          </table>
         <table bgcolor="f3f3f3" style="border: 1px solid; border-color: #cccccc;" width="100%" border="0" cellspacing="0" cellpadding="2">
          <tr>
          <td colspan="4"><?php echo twe_draw_separator('pixel_trans.gif', '1', '10'); ?></td>
          </tr>
          <tr>
          <?php
        $files=array();
 if ($dir= opendir(DIR_FS_CATALOG.'templates/'.CURRENT_TEMPLATE.'/module/product_listing/')){
 while  (($file = readdir($dir)) !==false) {
        if (is_file( DIR_FS_CATALOG.'templates/'.CURRENT_TEMPLATE.'/module/product_listing/'.$file) and ($file !="index.html")){
        $files[]=array(
                        'id' => $file,
                        'text' => $file);
        }//if
        } // while
        closedir($dir);
 }
 $default_array=array();
 // set default value in dropdown!
if ($content['content_file']=='') {
$default_array[]=array('id' => 'default','text' => TEXT_SELECT);
$default_value=$cInfo->listing_template;
$files=array_merge($default_array,$files);
} else {
$default_array[]=array('id' => 'default','text' => TEXT_NO_FILE);
$default_value=$cInfo->listing_template;
$files=array_merge($default_array,$files);
}
echo '<td class="main">'.TEXT_CHOOSE_INFO_TEMPLATE_LISTING.':</td>';
echo '<td><span class="main">'.twe_draw_pull_down_menu('listing_template',$files,$default_value,'id="cChange"').'</span></td>';

        $files=array();
 if ($dir= opendir(DIR_FS_CATALOG.'templates/'.CURRENT_TEMPLATE.'/module/categorie_listing/')){
 while  (($file = readdir($dir)) !==false) {
        if (is_file( DIR_FS_CATALOG.'templates/'.CURRENT_TEMPLATE.'/module/categorie_listing/'.$file) and ($file !="index.html")){
        $files[]=array(
                        'id' => $file,
                        'text' => $file);
        }//if
        } // while
        closedir($dir);
 }
 $default_array=array();
 // set default value in dropdown!
if ($content['content_file']=='') {
$default_array[]=array('id' => 'default','text' => TEXT_SELECT);
$default_value=$cInfo->categories_template;
$files=array_merge($default_array,$files);
} else {
$default_array[]=array('id' => 'default','text' => TEXT_NO_FILE);
$default_value=$cInfo->categories_template;
$files=array_merge($default_array,$files);
}
echo '<td class="main">'.TEXT_CHOOSE_INFO_TEMPLATE_CATEGORIE.':</td>';
echo '<td><span class="main">'.twe_draw_pull_down_menu('categories_template',$files,$default_value,'id="cChange"').'</span></td>';
?>
      </tr>
      <tr>
<?php
$order_array='';
$order_array=array(array('id' => 'p.products_date_added','text'=>TXT_DATE),
				   array('id' => 'p.products_price','text'=>TXT_PRICES),
                   array('id' => 'pd.products_name','text'=>TXT_NAME),
                   array('id' => 'p.products_ordered','text'=>TXT_ORDERED),
                   array('id' => 'p.products_sort','text'=>TXT_SORT),
                   array('id' => 'p.products_weight','text'=>TXT_WEIGHT),
                   array('id' => 'p.products_quantity','text'=>TXT_QTY));
//$default_value= $cInfo->products_sorting;
$order_array1='';
$order_array1=array(array('id' => 'ASC','text'=>'ASC (1 first)'),
                   array('id' => 'DESC','text'=>'DESC (1 last)'));

?>
            <td class="main"><?php echo TEXT_EDIT_PRODUCT_SORT_ORDER; ?>:</td>
            <td class="main"><?php echo twe_draw_pull_down_menu('products_sorting',$order_array,$cInfo->products_sorting,'id="cChange"'); ?></td>
            <td class="main" width="150"><?php echo TEXT_EDIT_PRODUCT_SORT_ORDER; ?>:</td>
            <td class="main"><?php echo twe_draw_pull_down_menu('products_sorting2',$order_array1,$cInfo->products_sorting2,'id="cChange"'); ?></td>
          </tr>
          <tr>
          <td class="main" width="150"><?php echo TEXT_EDIT_SORT_ORDER; ?></td>
          <td class="main"><?php echo twe_draw_input_field('sort_order', $cInfo->sort_order, 'id="cChange" size="5"').twe_draw_hidden_field('categories_status', $cInfo->categories_status); ?></td>
        <td class="main"></td>
        <td class="main"></td>
        </tr>
        </table>
 <div id="cgroup_tab">           
<?php
if (GROUP_CHECK=='true') {
$customers_statuses_array = twe_get_customers_statuses();
$customers_statuses_array=array_merge(array(array('id'=>'all','text'=>TXT_ALL)),$customers_statuses_array);
?><table class="ui-widget-content ui-corner-all" width="100%" border="0">
   <tr>
    <td colspan="4"><?php echo twe_draw_separator('pixel_trans.gif', '1', '10'); ?></td>
   </tr>
<tr>
<td style="border-top: 1px solid; border-color: #ff0000;" valign="top" class="main" ></td>
<td style="border-top: 1px solid; border-color: #ff0000;" valign="top" class="main" ></td>
<td style="border-top: 1px solid; border-color: #ff0000;" valign="top" class="main" ><?php echo ENTRY_CUSTOMERS_STATUS; ?></td>
<td style="border-top: 1px solid; border-left: 1px solid; border-color: #ff0000;"  bgcolor="#FFCC33" class="main">
<?php

for ($i=0;$n=sizeof($customers_statuses_array),$i<$n;$i++) {
if (strstr($category->fields['group_ids'],'c_'.$customers_statuses_array[$i]['id'].'_group')) {

$checked='checked ';
} else {
$checked='';
}
echo '<input id="cChecked" type="checkbox" name="groups[]" value="'.$customers_statuses_array[$i]['id'].'"'.$checked.'> '.$customers_statuses_array[$i]['text'].'<br>';
}
?>
</td>
</tr></table>
<?php
}
?>
</div>
<div id="Tabbed_categorie">
  <ul>
<?php    for ($i=0; $i<sizeof($languages); $i++) { ?>
   			 <li><a href="#<?php echo $languages[$i]['name']?>" class="<?php echo $languages[$i]['name']?>"><?php echo twe_image(DIR_WS_LANGUAGES . $languages[$i]['directory'] .'/'. $languages[$i]['image'], $languages[$i]['name']); ?></a></li>
<?php } ?>
</ul>

<?php    for ($i=0; $i<sizeof($languages); $i++) { ?>
<div id="<?php echo $languages[$i]['name']?>">
    <table border="0" cellspacing="0" cellpadding="0">
			<tr>
            <td class="main"><?php echo TEXT_EDIT_CATEGORIES_NAME; ?></td>
            <td class="main"><?php echo twe_draw_input_field('categories_name[' . $languages[$i]['id'] . ']', (($categories_name[$languages[$i]['id']]) ? stripslashes($categories_name[$languages[$i]['id']]) : twe_get_categories_name($cInfo->categories_id, $languages[$i]['id'])),'id="cdChange" size=60'); ?></td>
          </tr>
          <tr>
            <td class="main"><?php  echo TEXT_META_TITLE; ?></td>
            <td class="main"><?php echo twe_draw_input_field('categories_meta_title[' . $languages[$i]['id'] . ']', (($categories_meta_title[$languages[$i]['id']]) ? stripslashes($categories_meta_title[$languages[$i]['id']]) : twe_get_categories_meta_title($cInfo->categories_id, $languages[$i]['id'])),'id="cdChange" size=60'); ?></td>
          </tr>
           <tr>
            <td class="main"><?php  echo TEXT_META_DESCRIPTION; ?></td>
            <td class="main"><?php echo twe_draw_input_field('categories_meta_description[' . $languages[$i]['id'] . ']', (($categories_meta_description[$languages[$i]['id']]) ? stripslashes($categories_meta_description[$languages[$i]['id']]) : twe_get_categories_meta_description($cInfo->categories_id, $languages[$i]['id'])),'id="cdChange" size=60'); ?></td>
          </tr>
          <tr>
            <td class="main"><?php  echo TEXT_META_KEYWORDS; ?></td>
            <td class="main"><?php echo twe_draw_input_field('categories_meta_keywords[' . $languages[$i]['id'] . ']', (($categories_meta_keywords[$languages[$i]['id']]) ? stripslashes($categories_meta_keywords[$languages[$i]['id']]) : twe_get_categories_meta_keywords($cInfo->categories_id, $languages[$i]['id'])),'id="cdChange" size=60'); ?></td>
          </tr>
          <tr>
            <td class="main" valign="top"><?php  echo TEXT_EDIT_CATEGORIES_DESCRIPTION; ?></td>
            <td>
            
            <table border="0" cellspacing="0" cellpadding="0">
            <form id="categories_description_<?php echo $languages[$i]['id']?>">
              <tr>
                <td class="main" valign="top">&nbsp;</td>
                <td class="main"><?php echo twe_draw_textarea_field('categories_description[' . $languages[$i]['id'] . ']', 'soft', '70', '15', (($categories_description[$languages[$i]['id']]) ? stripslashes($categories_description[$languages[$i]['id']]) : twe_get_categories_description($cInfo->categories_id, $languages[$i]['id']))); ?></td>
              </tr>
              <tr>
  				<td colspan="2" align="right" class="main"><input type="submit" value="<?php echo IMAGE_UPDATE.TEXT_EDIT_CATEGORIES_DESCRIPTION?>" /></td>
  			 </tr></form>
            </table></td>
          </tr>
          </table></div>
<?php } ?>
</div>
	<table border="0" cellspacing="0" cellpadding="0">
        <tr>
        <td colspan="2"><?php echo twe_draw_separator('pixel_trans.gif', '1', '10'); ?></td>
        </tr>
