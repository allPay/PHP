<?php
/* -----------------------------------------------------------------------------------------
   $Id: image_processing.php,v 1.3 2004/04/25 13:58:08 oldpa   Exp $

   TWE-Commerce - community made shopping
   http://www.oldpa.com.tw
   Copyright (c) 2003 TWE-Commerce
   -----------------------------------------------------------------------------------------
   based on: 
   (c) 2000-2001 The Exchange Project  (earlier name of osCommerce)
   (c) 2002-2003 osCommerce(cod.php,v 1.28 2003/02/14); www.oscommerce.com 
   (c) 2003	 nextcommerce (invoice.php,v 1.6 2003/08/24); www.nextcommerce.org
   (c) 2003	 xt-commerce  www.xt-commerce.com

   Released under the GNU General Public License 
   ---------------------------------------------------------------------------------------*/
define('MODULE_STEP_IMAGE_PROCESS_TEXT_DESCRIPTION', '目錄中的所有商品圖<br /><br />

/images/product_images/popup_images/<br />

/images/product_images/info_images/<br />

/images/product_images/thumbnail_images/ <br /> <br /> 重製.<br /> <br /');
define('MODULE_STEP_IMAGE_PROCESS_TEXT_TITLE', 'Twe-圖片重製模組');
define('MODULE_STEP_IMAGE_PROCESS_STATUS_DESC','模組狀態');
define('MODULE_STEP_IMAGE_PROCESS_STATUS_TITLE','狀態');
define('IMAGE_EXPORT','按OK鍵啟動批次處理過程，這個過程可能需要一些時間來完成!.');
define('IMAGE_EXPORT_TYPE','<hr noshade><strong>批次處理:</strong>');

define('IMAGE_STEP_INFO','商品圖重製: ');
define('IMAGE_STEP_INFO_READY',' - 張商品圖完成!');
define('TEXT_MAX_IMAGES','最大。每頁面重製的商品圖');
define('TEXT_ONLY_MISSING_IMAGES','只重製缺少的商品圖');

if ( !class_exists( "image_processing" ) ) {
  class image_processing {
    var $code, $title, $description, $enabled;


    function image_processing() {
      global $order;
      $this->code = 'image_processing';
      $this->title = MODULE_IMAGE_PROCESS_TEXT_TITLE;
      $this->description = MODULE_IMAGE_PROCESS_TEXT_DESCRIPTION;
      $this->sort_order = MODULE_IMAGE_PROCESS_SORT_ORDER;
      $this->enabled = ((MODULE_IMAGE_PROCESS_STATUS == 'True') ? true : false);

    }


    function process($file,$offset) {
      global $limit, $self, $infotext, $count;
         // include needed functions
    require_once('includes/classes/image_manipulator.php');
	
	$ext_array = array('gif','jpg','jpeg','png'); //Gltige Dateiendungen

        @twe_set_time_limit(0);

        // action
        // get images in original_images folder
        if ($dir= opendir(DIR_FS_CATALOG_ORIGINAL_IMAGES)){
        while  ($file = readdir($dir)) {
          $tmp = explode('.',$file);
          if(is_array($tmp)) {
            $ext = strtolower($tmp[count($tmp)-1]);
            if (is_file(DIR_FS_CATALOG_ORIGINAL_IMAGES.$file) && in_array($ext,$ext_array) ){
              $files[]=array('id' => $file,
                             'text' =>$file);
            }
          }
        }
        closedir($dir);
      }
      $max_files = sizeof($files);
      $step = $_GET['max'];
      $count = $_GET['count'];
      $limit = $offset + $step;
    for ($i=$offset; $i<$limit; $i++) {
        if ($i >= $max_files) { 
          $infotext = urlencode(strip_tags(IMAGE_STEP_INFO) . $count. strip_tags(IMAGE_STEP_INFO_READY)) ;
          twe_redirect(twe_href_link(FILENAME_MODULE_EXPORT, 'set=' . $_GET['set'] . '&module='.$this->code.'&infotext='.$infotext. '&max='. $_GET['max'])); 
        }
        $products_image_name = $files[$i]['text'];

        if ($_GET['miss'] == 1) {
          $flag = false;
          if (!is_file(DIR_FS_CATALOG_THUMBNAIL_IMAGES.$files[$i]['text'])) {
            require(DIR_WS_INCLUDES . 'product_thumbnail_images.php'); $flag = true;
          }
          if (!is_file(DIR_FS_CATALOG_INFO_IMAGES.$files[$i]['text'])) {
            require(DIR_WS_INCLUDES . 'product_info_images.php'); $flag = true;
          }
          if (!is_file(DIR_FS_CATALOG_POPUP_IMAGES.$files[$i]['text'])) {
            require(DIR_WS_INCLUDES . 'product_popup_images.php'); $flag = true;
          }
          if ($flag) {
            $count += 1;
          }
        } else {
          require(DIR_WS_INCLUDES . 'product_thumbnail_images.php');
          require(DIR_WS_INCLUDES . 'product_info_images.php');
          require(DIR_WS_INCLUDES . 'product_popup_images.php');
          $count += 1;
        }
      }
      
      $info_wait = '<img src="images/loading.gif"> ';
      $infotext = '<div style="margin:10px; font-family:Verdana; font-size:15px; text-align:center;">'.$info_wait . IMAGE_STEP_INFO . $count.'</div>';
      $self = '<script language="javascript" type="text/javascript">setTimeout("document.modul_continue.submit()", 3000);</script>';
    }

    function display() {
      $max_array = array (array ('id' => '5', 'text' => '5'));
      $max_array[] = array ('id' => '10', 'text' => '10');
      $max_array[] = array ('id' => '15', 'text' => '15');
      $max_array[] = array ('id' => '20', 'text' => '20');
      $max_array[] = array ('id' => '50', 'text' => '50');

      return array('text' => twe_draw_hidden_field('process','module_processing_do').
                             twe_draw_hidden_field('max_images1','5').
                             IMAGE_EXPORT_TYPE.'<br />'.
                             IMAGE_EXPORT.'<br />'.
                             '<br />' . twe_draw_pull_down_menu('max_datasets', $max_array, '5'). ' ' . TEXT_MAX_IMAGES. '<br />'.
                             '<br />' . twe_draw_checkbox_field('only_missing_images', '1', false) . ' ' . TEXT_ONLY_MISSING_IMAGES. '<br />'.
                             '<br />' . twe_image_submit('button_review_approve.gif', IMAGE_UPDATE). '&nbsp;<br />'.
							 '<a href="' . twe_href_link(FILENAME_MODULE_EXPORT, 'set=' . $_GET['set'] . '&module=image_processing') . '">' .twe_image_button('button_cancel.gif', IMAGE_CANCEL) . '</a>'
                   );   

    }

    function check() {
	      global $db;
      if (!isset($this->_check)) {
        $check_query = $db->Execute("select configuration_value from " . TABLE_CONFIGURATION . " where configuration_key = 'MODULE_IMAGE_PROCESS_STATUS'");
        $this->_check = $check_query->RecordCount();
      }
      return $this->_check;
    }

    function install() {
		      global $db;
      $db->Execute("insert into " . TABLE_CONFIGURATION . " (configuration_key, configuration_value,  configuration_group_id, sort_order, set_function, date_added) values ('MODULE_IMAGE_PROCESS_STATUS', 'True',  '6', '1', 'twe_cfg_select_option(array(\'True\', \'False\'), ', now())");
}

    function remove() {
		      global $db;
      $db->Execute("delete from " . TABLE_CONFIGURATION . " where configuration_key in ('" . implode("', '", $this->keys()) . "')");
    }

    function keys() {
      return array('MODULE_IMAGE_PROCESS_STATUS');
    }

  }
}
?>