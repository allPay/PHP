<?php
/* --------------------------------------------------------------
   $Id: includes.js.php,v 1.4 2012/08/29 17:05:18 oldpa Exp $   

   TWE-Commerce - community made shopping
   http://www.oldpa.com.tw

   Copyright (c) 2003 TWE-Commerce
   --------------------------------------------------------------
   based on: 
   (c) 2000-2001 The Exchange Project  (earlier name of osCommerce)
   (c) 2002-2003 osCommerce(configuration.php,v 1.40 2002/12/29); www.oscommerce.com 
   (c) 2003	 nextcommerce (configuration.php,v 1.16 2003/08/19); www.nextcommerce.org
   (c) 2003-2004 xt-commerce  www.xt-commerce.com

   Released under the GNU General Public License 
   --------------------------------------------------------------*/
?>
<link rel="stylesheet" type="text/css" href="../ext/jquery/ui/start/jquery-ui-1.8.16.custom.css" media="screen" />
<script src="../ext/jquery/jquery-1.7.min.js" type="text/javascript"></script>
<script type="text/javascript" language="javascript" src="../ext/jquery/jquery-ui-1.8.16.custom.min.js"></script>
<script type="text/javascript" language="javascript" src="../ext/jquery/jquery.cookie.js"></script>
