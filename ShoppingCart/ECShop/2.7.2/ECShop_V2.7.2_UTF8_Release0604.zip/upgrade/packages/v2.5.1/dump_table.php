<?php

$temp = array('admin_action', 'shop_config', 'mail_templates');

?>
