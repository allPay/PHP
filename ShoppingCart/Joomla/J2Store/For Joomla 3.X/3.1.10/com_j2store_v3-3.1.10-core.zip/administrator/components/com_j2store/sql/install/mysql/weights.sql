INSERT INTO `#__j2store_weights` (`j2store_weight_id`, `weight_title`, `weight_unit`, `weight_value`, `enabled`) VALUES
(1, 'Kilogram', 'kg', 1.00000000, 1),
(2, 'Gram', 'g', 1000.00000000, 1),
(3, 'Ounce', 'oz', 35.27400000, 1),
(4, 'Pound', 'lb', 2.20462000, 1);
