INSERT INTO `#__j2store_lengths` (`j2store_length_id`, `length_title`, `length_unit`, `length_value`, `enabled`) VALUES
(1, 'Centimetre', 'cm', 1.00000000, 1),
(2, 'Inch', 'in', 0.39370000, 1),
(3, 'Millimetre', 'mm', 10.00000000, 1);

