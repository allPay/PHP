DROP TABLE IF EXISTS `#__j2store_countries`;
