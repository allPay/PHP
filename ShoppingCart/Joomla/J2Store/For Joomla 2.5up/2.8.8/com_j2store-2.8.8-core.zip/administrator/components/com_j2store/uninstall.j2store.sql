DROP TABLE IF EXISTS `#__j2store_zones`;
DROP TABLE IF EXISTS `#__j2store_countries`;