<?php
/*------------------------------------------------------------------------
 # com_j2store - J2Store
# ------------------------------------------------------------------------
# author    Ramesh Elamathi - Weblogicx India http://www.weblogicxindia.com
# copyright Copyright (C) 2014 - 19 Weblogicxindia.com. All Rights Reserved.
# @license - http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
# Websites: http://j2store.org
-------------------------------------------------------------------------*/
// Protect from unauthorized access
defined('_JEXEC') or die('Restricted Access');

define('J2STORE_PRO', '0');
define('J2STORE_VERSION', '2.8.8');
define('J2STORE_DATE', '2015-06-08');
define('J2STORE_PRO_URL', 'http://j2store.org/download.html');
